Akari - Light Up Game made by using Kotlin language in Android Studio
